package com.selenium.driver;

import org.openqa.selenium.WebDriver;

public interface DriverStrategy {
	
	public WebDriver setStrategy();
}
